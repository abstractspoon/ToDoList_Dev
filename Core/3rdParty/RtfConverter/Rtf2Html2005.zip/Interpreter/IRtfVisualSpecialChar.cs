﻿// -- FILE ------------------------------------------------------------------
// name       : IRtfVisualSpecialChar.cs
// project    : RTF Framelet
// created    : Leon Poyyayil - 2008.05.22
// language   : c#
// environment: .NET 2.0
// copyright  : (c) 2004-2009 by Itenso GmbH, Switzerland
// --------------------------------------------------------------------------

namespace Itenso.Rtf
{

	// ------------------------------------------------------------------------
	public interface IRtfVisualSpecialChar : IRtfVisual
	{

		// ----------------------------------------------------------------------
		RtfVisualSpecialCharKind CharKind { get; }

	} // interface IRtfVisualSpecialChar

} // namespace Itenso.Rtf
// -- EOF -------------------------------------------------------------------
