﻿// -- FILE ------------------------------------------------------------------
// name       : IRtfVisualBreak.cs
// project    : RTF Framelet
// created    : Leon Poyyayil - 2008.05.22
// language   : c#
// environment: .NET 2.0
// copyright  : (c) 2004-2009 by Itenso GmbH, Switzerland
// --------------------------------------------------------------------------

namespace Itenso.Rtf
{

	// ------------------------------------------------------------------------
	public interface IRtfVisualBreak : IRtfVisual
	{

		// ----------------------------------------------------------------------
		RtfVisualBreakKind BreakKind { get; }

	} // interface IRtfVisualBreak

} // namespace Itenso.Rtf
// -- EOF -------------------------------------------------------------------
