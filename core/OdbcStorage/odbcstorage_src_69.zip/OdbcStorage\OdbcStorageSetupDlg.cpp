// OdbcStorageSetupDlg.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"
#include "OdbcStorageSetupDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COdbcStorageSetupDlg dialog


COdbcStorageSetupDlg::COdbcStorageSetupDlg(CDatabase& db, CWnd* pParent /*=NULL*/)
	: CDialog(IDD_SETUP_DIALOG, pParent), m_db(db)
{
	//{{AFX_DATA_INIT(COdbcStorageSetupDlg)
	m_sTasksTable = _T("");
	//}}AFX_DATA_INIT
}


void COdbcStorageSetupDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(COdbcStorageSetupDlg)
	DDX_Control(pDX, IDC_TASKSTABLE, m_cbTasksTable);
	DDX_Control(pDX, IDC_ATTRIBUTESETUP, m_lcAttribSetup);
	DDX_CBString(pDX, IDC_TASKSTABLE, m_sTasksTable);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(COdbcStorageSetupDlg, CDialog)
	//{{AFX_MSG_MAP(COdbcStorageSetupDlg)
	ON_BN_CLICKED(IDC_VALIDATE, OnValidate)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COdbcStorageSetupDlg message handlers

void COdbcStorageSetupDlg::OnValidate() 
{
	// TODO: Add your control notification handler code here
	
}

BOOL COdbcStorageSetupDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	m_cbTasksTable.Initialize(&m_db);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
