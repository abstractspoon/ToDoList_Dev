// OdbcTasklistStorage.h: interface for the COdbcTasklistStorage class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ODBCTASKLISTSTORAGE_H__1A49027C_CC71_4EB8_8540_B319AB9A045E__INCLUDED_)
#define AFX_ODBCTASKLISTSTORAGE_H__1A49027C_CC71_4EB8_8540_B319AB9A045E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "..\shared\ITaskListStorage.h"

#include <afxdb.h>

class ITransText;

class COdbcTasklistStorage : public ITasklistStorage  
{
public:
	COdbcTasklistStorage();
	virtual ~COdbcTasklistStorage();

	// interface implementation
    void Release() { delete this; }
	void SetLocalizer(ITransText* pTT);

	// caller must copy result only
	LPCTSTR GetMenuText() const { return _T("ODBC Connection"); }
	HICON GetIcon() const { return m_hIcon; }
	LPCTSTR GetTypeID() const { return _T("1A49027C_CC71_4EB8_8540_B319AB9A045E"); }
	
	bool RetrieveTasklist(ITS_TASKLISTINFO* pFInfo, ITaskList* pDestTaskFile, IPreferences* pPrefs, LPCTSTR szKey, bool bSilent);
	bool StoreTasklist(ITS_TASKLISTINFO* pFInfo, const ITaskList* pSrcTaskFile, IPreferences* pPrefs, LPCTSTR szKey, bool bSilent);

protected:
	HICON m_hIcon;
	CDatabase m_db;
};

#endif // !defined(AFX_ODBCTASKLISTSTORAGE_H__1A49027C_CC71_4EB8_8540_B319AB9A045E__INCLUDED_)
