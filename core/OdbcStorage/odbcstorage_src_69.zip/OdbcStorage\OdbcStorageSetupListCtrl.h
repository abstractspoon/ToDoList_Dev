#if !defined(AFX_ODBCSTORAGESETUPLISTCTRL_H__4C4EEC88_20DB_4DAC_A8B2_ED9E0E3E83A4__INCLUDED_)
#define AFX_ODBCSTORAGESETUPLISTCTRL_H__4C4EEC88_20DB_4DAC_A8B2_ED9E0E3E83A4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// OdbcStorageSetupListCtrl.h : header file
//

#include "..\Shared\InputListCtrl.h"
#include "..\todolist\tdcenum.h"

#include <afxdb.h>

/////////////////////////////////////////////////////////////////////////////
// COdbcStorageSetupListCtrl window

struct ODBCATTRIBUTESETUP
{
	TDC_ATTRIBUTE nAttrib;

	CString sTaskTable;
	CString sTaskField;

	CString sAttribTable;
	CString sAttribField;

	CString sLinkTable;
	CString sLinkTaskField;
	CString sLinkAttribField;
};
typedef CArray<ODBCATTRIBUTESETUP, ODBCATTRIBUTESETUP&> COdbcAttribSetupArray;

class COdbcStorageSetupListCtrl : public CInputListCtrl
{
// Construction
public:
	COdbcStorageSetupListCtrl();

	BOOL Initialise(CDatabase& db, const COdbcAttribSetupArray& aAttribSetup);
	BOOL GetAttributeSetup(COdbcAttribSetupArray& aAttribSetup) const;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COdbcStorageSetupListCtrl)
	protected:
	virtual void PreSubclassWindow();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~COdbcStorageSetupListCtrl();

	// Generated message map functions
protected:
	//{{AFX_MSG(COdbcStorageSetupListCtrl)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()

protected:
	void BuildListColumns();
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ODBCSTORAGESETUPLISTCTRL_H__4C4EEC88_20DB_4DAC_A8B2_ED9E0E3E83A4__INCLUDED_)
