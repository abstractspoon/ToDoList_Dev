// OdbcTasklistStorage.cpp: implementation of the COdbcTasklistStorage class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "resource.h"
#include "OdbcTasklistStorage.h"
#include "OdbcRecordset.h"
#include "OdbcStorageSetupdlg.h"

#include "..\shared\ITaskList.h"
#include "..\shared\localizer.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

COdbcTasklistStorage::COdbcTasklistStorage() : m_hIcon(NULL)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_ODBCSTORAGE);
}

COdbcTasklistStorage::~COdbcTasklistStorage()
{

}

void COdbcTasklistStorage::SetLocalizer(ITransText* pTT)
{
	CLocalizer::Initialize(pTT);
}

bool COdbcTasklistStorage::RetrieveTasklist(ITS_TASKLISTINFO* pFInfo, ITaskList* pDestTaskFile, IPreferences* pPrefs, LPCTSTR szKey, bool bSilent)
{
#ifdef _DEBUG
	CString sConnect = "ODBC;";
	
	if (!m_db.Open(NULL, FALSE, FALSE, sConnect, TRUE))
		return false;

	COdbcStorageSetupDlg dialog(m_db);

	dialog.DoModal();


#else
	AfxMessageBox(_T("ODBC Database Plugin Coming Soon"));
#endif

	return false;
}

bool COdbcTasklistStorage::StoreTasklist(ITS_TASKLISTINFO* pFInfo, const ITaskList* pSrcTaskFile, IPreferences* pPrefs, LPCTSTR szKey, bool bSilent)
{
#ifdef _DEBUG
	
#else
	AfxMessageBox(_T("ODBC Database Plugin Coming Soon"));
#endif

	return false;
}
