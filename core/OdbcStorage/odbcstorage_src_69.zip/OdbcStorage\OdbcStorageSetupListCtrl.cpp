// OdbcStorageSetupListCtrl.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"
#include "OdbcStorageSetupListCtrl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

enum 
{
	LISTCOL_TASKATTRIB,
	LISTCOL_TASKFIELD,
	LISTCOL_ATTRIBTABLE,
	LISTCOL_ATTRIBFIELD,
	LISTCOL_LINKTABLE,
	LISTCOL_LINKTASKFIELD,
	LISTCOL_LINKATTRIBFIELD,


	LISTCOL_NUM
};

const UINT LISTCOL_NAMES[LISTCOL_NUM] = 
{
	IDS_TASKATTRIB_COL,
	IDS_TASKFIELD_COL,
	IDS_ATTRIBTABLE_COL,
	IDS_ATTRIBFIELD_COL,
	IDS_LINKTABLE_COL,
	IDS_LINKTASKFIELD_COL,
	IDS_LINKATTRIBFIELD_COL,
};

const UINT TASKATTRIB_NAMES[][2] = 
{
	{ TDCA_TASKNAME,		IDS_TA_TASKNAME },
	{ TDCA_DONEDATE,		IDS_TA_DONEDATE },
	{ TDCA_DUEDATE,			IDS_TA_DUEDATE },
	{ TDCA_STARTDATE,		IDS_TA_STARTDATE },
	{ TDCA_PRIORITY,		IDS_TA_PRIORITY },
	{ TDCA_COLOR,			IDS_TA_COLOR },
	{ TDCA_ALLOCTO,			IDS_TA_ALLOCTO },
	{ TDCA_ALLOCBY,			IDS_TA_ALLOCBY },
	{ TDCA_STATUS,			IDS_TA_STATUS },
	{ TDCA_CATEGORY,		IDS_TA_CATEGORY },
	{ TDCA_PERCENT,			IDS_TA_PERCENT },
	{ TDCA_TIMEEST,			IDS_TA_TIMEEST },
	{ TDCA_TIMESPENT,		IDS_TA_TIMESPENT },
	{ TDCA_FILEREF,			IDS_TA_FILEREF },
	{ TDCA_COMMENTS,		IDS_TA_COMMENTS },
	{ TDCA_PROJNAME,		IDS_TA_PROJNAME },
	{ TDCA_FLAG,			IDS_TA_FLAG },
	{ TDCA_CREATIONDATE,	IDS_TA_CREATIONDATE },
	{ TDCA_CREATEDBY,		IDS_TA_CREATEDBY },
	{ TDCA_RISK,			IDS_TA_RISK },			
	{ TDCA_EXTERNALID,		IDS_TA_EXTERNALID },	
	{ TDCA_COST,			IDS_TA_COST },			
	{ TDCA_DEPENDENCY,		IDS_TA_DEPENDENCY },	
	{ TDCA_RECURRENCE,		IDS_TA_RECURRENCE },	
	{ TDCA_VERSION,			IDS_TA_VERSION },		
	{ TDCA_POSITION,		IDS_TA_POSITION },
	{ TDCA_ID,				IDS_TA_ID },
	{ TDCA_LASTMOD,			IDS_TA_LASTMOD },
	{ TDCA_DUETIME,			IDS_TA_DUETIME },
	{ TDCA_ICON,			IDS_TA_ICON },
	{ TDCA_STARTTIME,		IDS_TA_STARTTIME },
	{ TDCA_DONETIME,		IDS_TA_DONETIME },
	{ TDCA_TAGS,			IDS_TA_TAGS },
	{ TDCA_PARENTID,		IDS_TA_PARENTID },
};

/////////////////////////////////////////////////////////////////////////////
// COdbcStorageSetupListCtrl

COdbcStorageSetupListCtrl::COdbcStorageSetupListCtrl()
{
}

COdbcStorageSetupListCtrl::~COdbcStorageSetupListCtrl()
{
}


BEGIN_MESSAGE_MAP(COdbcStorageSetupListCtrl, CInputListCtrl)
	//{{AFX_MSG_MAP(COdbcStorageSetupListCtrl)
	ON_WM_CREATE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COdbcStorageSetupListCtrl message handlers

int COdbcStorageSetupListCtrl::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CInputListCtrl::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	BuildListColumns();
	
	return 0;
}

void COdbcStorageSetupListCtrl::PreSubclassWindow() 
{
	BuildListColumns();
	
	CInputListCtrl::PreSubclassWindow();
}

void COdbcStorageSetupListCtrl::BuildListColumns()
{
	// once only
	if (GetColumnCount())
		return;

	for (int nCol = 0; nCol < LISTCOL_NUM; nCol++)
		InsertColumn(nCol, CEnString(LISTCOL_NAMES[nCol]), LVCFMT_LEFT, 100);

	// build the task attribute column
}
