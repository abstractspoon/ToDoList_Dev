//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by OdbcStorage.rc
//
#define IDS_TASKATTRIB_COL              1
#define IDS_TASKFIELD_COL               2
#define IDS_ATTRIBTABLE_COL             3
#define IDS_ATTRIBFIELD_COL             4
#define IDS_LINKTABLE_COL               5
#define IDS_LINKTASKFIELD_COL           6
#define IDS_LINKATTRIBFIELD_COL         7
#define IDC_TASKSTABLE                  2000
#define IDR_ODBCSTORAGE                 2001
#define IDC_ATTRIBUTESETUP              2001
#define IDD_SETUP_DIALOG                2002
#define IDC_VALIDATE                    2002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        2003
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         2003
#define _APS_NEXT_SYMED_VALUE           2000
#endif
#endif
